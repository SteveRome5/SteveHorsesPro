# Auto-generated overlay weights (calibrated)
# trained_on_rows=94050  generated=2025-09-17 05:54:52
# Usage:  source /Users/stephenjerome/Desktop/SteveHorsesPro/outputs/overlay_tune_2025-09-17.sh

export W_TJ=0.175
export W_CYCLE=0.15
export W_PACE=0.175
export W_BIAS=0.12
export W_SHIP=0.1
